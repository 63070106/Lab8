package com.sop.chapter6.testservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
